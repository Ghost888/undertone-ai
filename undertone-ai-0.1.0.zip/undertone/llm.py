"""Backends: the only place where actual model calls happen.

The prototype talks to a backend through one method, ``complete(role, payload)``,
where *role* is ``light``, ``heavy`` or ``expression`` and *payload* is a small
JSON-serializable dict. The backend returns a JSON string.

Two implementations ship:

* :class:`MockBackend` - deterministic, offline, no dependencies. It exists so
  the architecture can be run and tested without a model, and it doubles as a
  living specification of the payload/response schema.
* :class:`OpenAICompatBackend` - any OpenAI-compatible ``/chat/completions``
  endpoint (vLLM, Ollama, llama.cpp server, OpenAI, ...), using only urllib.
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from typing import Any, Dict, Optional

from .config import Config

SYSTEM_PROMPTS = {
    "light": (
        "You are the always-on light thinking layer of a real-time text dialogue "
        "system. You see the recent input events (typing, pause, send, interrupt) "
        "and the current understanding. Continue thinking without speaking: update "
        "the understanding, revise thoughts incrementally (do not rewrite them from "
        "scratch), mark unfinished input as tentative, and decide whether the "
        "question deserves the heavy layer. Reply with JSON only:\n"
        '{"understanding": str, "intent": "question" | "answer" | "chitchat", '
        '"thoughts": [{"id": str, "text": str, "confidence": "tentative"}], '
        '"needs_deep_thought": bool}'
    ),
    "heavy": (
        "You are the on-demand heavy thinking layer. You are called when the light "
        "layer judged that something is worth deeper thought. Produce the one "
        "thought that should guide the answer. Reply with JSON only:\n"
        '{"thought": str, "confidence": "confirmed"}'
    ),
    "expression": (
        "You are the expression layer. You may only propose what to say, never "
        "output it. Using the confirmed thoughts, write one short candidate "
        "utterance in the user's language. Reply with JSON only:\n"
        '{"text": str}'
    ),
}


def parse_json(raw: Any) -> Optional[dict]:
    """Parse model output, tolerating markdown fences and leading chatter."""

    if isinstance(raw, dict):
        return raw
    if not isinstance(raw, str):
        return None
    text = raw.strip()
    if not text:
        return None
    if text.startswith("```"):
        text = text.split("```", 2)[1] if text.count("```") >= 2 else text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    text = text.strip()
    try:
        value = json.loads(text)
        return value if isinstance(value, dict) else None
    except ValueError:
        start = text.find("{")
        end = text.rfind("}")
        if start == -1 or end <= start:
            return None
        try:
            value = json.loads(text[start : end + 1])
            return value if isinstance(value, dict) else None
        except ValueError:
            return None


def gist(text: str, limit: int = 80) -> str:
    text = " ".join((text or "").split())
    return text if len(text) <= limit else text[: limit - 1] + "\u2026"


def looks_like_question(text: str) -> bool:
    text = (text or "").strip()
    if not text:
        return False
    if "?" in text or "\uff1f" in text:
        return True
    if text.endswith(("\u5417", "\u5462")):
        return True
    lowered = text.lower()
    starters = (
        "how", "why", "what", "when", "where", "which", "who",
        "can", "could", "do", "does", "did", "is", "are", "should", "would",
    )
    return lowered.startswith(starters)


class MockBackend:
    """A deterministic stand-in for a model: no network, stable output."""

    name = "mock"

    def __init__(self, latency: float = 0.0, heavy_latency: Optional[float] = None) -> None:
        self.latency = latency
        self.heavy_latency = latency if heavy_latency is None else heavy_latency

    # -- Backend interface ------------------------------------------------
    def complete(self, role: str, payload: Dict[str, Any]) -> str:
        if role == "heavy" and self.heavy_latency:
            time.sleep(self.heavy_latency)
        elif self.latency:
            time.sleep(self.latency)
        if role == "light":
            return json.dumps(self._light(payload), ensure_ascii=False)
        if role == "heavy":
            return json.dumps(self._heavy(payload), ensure_ascii=False)
        if role == "expression":
            return json.dumps(self._expression(payload), ensure_ascii=False)
        return json.dumps({})

    # -- fixtures ---------------------------------------------------------
    def _light(self, payload: Dict[str, Any]) -> dict:
        events = payload.get("events") or []
        kinds = {str(event.get("kind") or "") for event in events}
        text = str(payload.get("last_user_text") or "")
        previous = str(payload.get("understanding") or "").strip()
        summary = gist(text)
        question = looks_like_question(text)

        if not summary:
            return {
                "understanding": previous,
                "intent": payload.get("intent") or "answer",
                "thoughts": [],
                "needs_deep_thought": False,
            }

        if "send" in kinds:
            understanding = summary
            thought = (
                "The user asks: %s. Answer the question directly, then give one "
                "concrete example." % summary
                if question
                else "The user says: %s. Acknowledge it and continue from there." % summary
            )
        elif "interrupt" in kinds:
            understanding = summary
            thought = (
                "The user interrupted with: %s. Fold this into the current line of "
                "thought instead of starting over." % summary
            )
        else:
            understanding = summary if summary not in previous else previous
            if previous and summary not in previous:
                understanding = (previous + " / " + summary)[-200:]
            thought = "The user is still typing: %s (unfinished, keep it tentative)." % summary

        return {
            "understanding": understanding,
            "intent": "question" if question else "answer",
            "thoughts": [{"text": thought, "confidence": "tentative"}],
            "needs_deep_thought": ("send" in kinds) or question or ("interrupt" in kinds),
        }

    def _heavy(self, payload: Dict[str, Any]) -> dict:
        summary = gist(str(payload.get("understanding") or ""), limit=120) or "the message"
        if (payload.get("intent") or "") == "question":
            thought = (
                "Answer %s in one short paragraph; add one concrete next step only "
                "if it helps." % summary
            )
        else:
            thought = "Respond briefly to %s, then ask nothing unless it is needed." % summary
        return {"thought": thought, "confidence": "confirmed"}

    def _expression(self, payload: Dict[str, Any]) -> dict:
        summary = gist(str(payload.get("understanding") or ""), limit=60)
        thoughts = payload.get("thoughts") or []
        plan = str((thoughts[0] or {}).get("text") or "") if thoughts else ""
        if (payload.get("intent") or "") == "question":
            text = "Short version: here is my take on %s." % (summary or "that")
        elif summary:
            text = "Got it \u2014 %s. Let me pick that up." % summary
        else:
            text = "Got it \u2014 let me pick that up."
        return {"text": text, "plan": plan}


class OpenAICompatBackend:
    """Any OpenAI-compatible /chat/completions endpoint, via urllib."""

    name = "openai"

    def __init__(
        self,
        base_url: str,
        model: str,
        api_key: str = "",
        timeout: float = 60.0,
        temperature: float = 0.4,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.api_key = api_key
        self.timeout = timeout
        self.temperature = temperature

    def complete(self, role: str, payload: Dict[str, Any]) -> str:
        url = self.base_url + "/chat/completions"
        body = {
            "model": self.model,
            "temperature": self.temperature,
            "messages": [
                {"role": "system", "content": SYSTEM_PROMPTS.get(role, "")},
                {"role": "user", "content": json.dumps(payload, ensure_ascii=False)},
            ],
        }
        data = json.dumps(body).encode("utf-8")
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = "Bearer " + self.api_key
        request = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(request, timeout=self.timeout) as response:
            parsed = json.loads(response.read().decode("utf-8"))
        return parsed["choices"][0]["message"]["content"]


def make_backend(config: Config, role: str = "light"):
    """Build the backend for a role from the config."""

    if (config.backend or "mock").lower() == "openai":
        model = config.heavy_model if role == "heavy" else config.light_model
        return OpenAICompatBackend(
            base_url=config.base_url,
            model=model,
            api_key=config.api_key,
            timeout=config.request_timeout,
        )
    return MockBackend(latency=config.mock_latency, heavy_latency=config.mock_heavy_latency)
