# Design notes: what this skeleton does, and what it deliberately does not

The repository started as a concept and now has a skeleton. This note keeps the
gap between the two honest, so the next contributor does not mistake a stub for
a result.

## Implemented

* A versioned blackboard with staleness checks (`state.py`).
* Event-based perception with inferred pauses (`perception.py`).
* Always-on light layer and on-demand heavy layer, both revision-based
  (`thinking/`).
* Expression that can only propose, and a scheduler that is the only exit
  (`expression.py`, `scheduler.py`).
* Offline deterministic backend plus an OpenAI-compatible one (`llm.py`).
* Scripted scenarios, a demo, an interactive chat, a turn-based baseline and a
  comparison harness (`scenarios.py`, `cli.py`, `experiments/`).
* Tests for versioning, staleness, the policy and an end-to-end conversation
  (`tests/`).

## Not implemented (on purpose, for now)

* **Memory and self-monitoring** are phase 2. The state has room for them; no
  module writes `source="memory"` yet.
* **KV-cache reuse / incremental prefill** is an engineering claim, not code.
  Every light call currently resends the understanding and the event window.
* **A learned turn-taking policy.** Phase 1 is rule-based with four constants.
  The `View` dataclass is the intended feature vector.
* **Real evaluation.** `experiments/compare.py` produces latency numbers from
  mock backends with artificial delays. Those numbers validate the harness, not
  the hypotheses. Running it with `--backend openai` against the same base model
  in both architectures is the first real experiment.
* **Naturalness measurement.** Latency and staleness counts are automated;
  pairwise preference and coherence-after-interruption are still manual.
* **Speech.** Text only, as stated in the README.

## Decisions worth recording

* **Thoughts are keyed, upserts are idempotent.** Without this, a light layer
  that keeps re-thinking would move versions constantly and make every draft
  stale. The design principle "revise incrementally" is enforced by the state,
  not by prompt politeness.
* **Only the heavy layer confirms.** Tentative thoughts are filtered out in
  Expression. This keeps speculative content away from output and makes H5-style
  mistakes visible in the transcript.
* **The scheduler does not speak before `send`.** Pre-computed drafts exist and
  make the post-send reply fast, but nothing is emitted while the user is still
  typing except backchannels. An earlier "eager" variant spoke mid-typing; it
  felt like being interrupted and made the H1 comparison meaningless. This is an
  open design question, not a settled one.
* **Stale drafts are dropped, not patched.** Patching a sentence whose premise
  changed produces fluent nonsense. Instead, after a drop the expression layer
  immediately drafts again from the current thoughts, so the cost of dropping is
  one extra model call.
* **Backchannel text is canned.** Three fixed strings are enough to study
  timing; generating them is a separate, easier problem.
* **No lock on the state.** One event loop, short synchronous writes. If a host
  feeds events from another thread, marshalling is the host's job.

## Open questions

1. **How light can the light layer be?** Today it is a full model call per event
   window. A small classifier plus a cached KV prefix may be enough; nothing here
   answers that.
2. **How much revision should invalidate a draft?** Any version bump is currently
   fatal. A semantic threshold ("the premise changed") would be more forgiving
   and cheaper.
3. **Should interruption clear pending drafts?** Interruptions set new thoughts,
   which stale-drops most drafts indirectly. Making that explicit might be more
   honest than relying on the version check.
4. **What is the right pacing?** All timings (`pause_after`, `backchannel_after`,
   cooldowns) are guesses. They need to be fitted to human typing data.
5. **How is "presence" measured?** Pairwise preference on short clips of the
   dialogue, plus interaction logs. Both need a protocol before any claim.

## A note on the mock backend

`MockBackend` is not a model and is not meant to look like one. It returns
canned text derived from a summary of the user's message, and it exists for
three reasons: the prototype can be run and tested offline, the JSON contracts
are executable documentation, and the comparison harness can be exercised
without spending money. Any qualitative claim about the architecture requires a
real backend.
