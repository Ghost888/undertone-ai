# Architecture notes

This document describes the contracts the skeleton implements. It is the place
to look before changing a module.

## Data flow

```
input stream ──> Perception ──> SharedState ──> LightThinker ──┐
                                     ▲                          │ (deltas)
                                     │                          ▼
                                     │                     SharedState
                                     ├──> HeavyThinker ──> Expression ──> drafts
                                     │                                    │
                                     └──> Scheduler <─────────────────────┘
                                              │
                                              └──> output + "already said" written back
```

Modules never call each other. They only call methods on `SharedState`, and
`SharedState` wakes listeners after every write.

## The shared state (`undertone/state.py`)

Records:

| Field | Meaning |
|---|---|
| `input_events` | What happened in the input stream: typing, pause, send, interrupt, edit |
| `understanding` | Current best reading of what the user means, revised incrementally |
| `intent` | `question` / `answer` / `chitchat` |
| `thoughts` | `{id: Thought}`; each thought has `text`, `confidence`, `version`, `source` |
| `pending` | Drafts that Expression proposed and the Scheduler has not released |
| `spoken` | What was actually said, with the thought versions it was based on |
| `dropped` | Drafts that were thrown away, with the reason |
| `signals` | Cheap flags that must not invalidate thoughts (`typing`, `last_send`, `last_spoken`, ...) |
| `needs_deep_thought` | A request from the light layer to the heavy layer |

### Versioning rules

1. Every mutating call bumps `state.version` and notifies listeners.
2. `upsert_thought` **does not** bump if the text and confidence are unchanged.
   Re-thinking the same thought must not invalidate drafts built on it; this is
   what makes "thinking during input" pay off.
3. A `Thought.version` is the state version at the moment it was last written.
4. An `Utterance` records `thought_versions = {thought_id: version}`.
5. `state.is_stale(utterance)` is true if any recorded version differs from the
   current one (or the thought is gone).

Consequence: a draft is spoken only if every thought it was built on is still
current. Otherwise it is moved to `dropped` with a reason, and if the draft had
already been spoken the scheduler may emit a correction (H3).

## Modules

### Perception (`perception.py`)

Turns the host's input callbacks into events. It also infers `PAUSE` from a
typing stream that goes quiet (`config.pause_after`) and clears the typing flag
after `config.typing_timeout`.

It does not interpret text. That belongs to the thinking layers.

### Light layer (`thinking/light.py`)

Runs on every new event (rate-limited by `config.light_min_interval`). Sends the
recent events plus the current understanding to the light model and applies the
returned delta: understanding, intent, tentative thoughts, and possibly a
request for the heavy layer.

It may only write `tentative` thoughts. It never confirms.

### Heavy layer (`thinking/heavy.py`)

Runs when `state.needs_deep_thought` is set and the cooldown has passed. It
writes one confirmed thought (`heavy:plan`). Because `upsert_thought` is
idempotent, re-escalating to the same conclusion does not invalidate drafts.

### Expression (`expression.py`)

Reads confirmed thoughts and proposes one draft. The draft carries the thought
versions it used. Expression has no output channel: it cannot speak, and this is
enforced by it not holding the transcript.

### Scheduler (`scheduler.py`)

The only module with an output channel. Phase 1 policy (`choose_action`):

1. If the user sent something and a valid draft exists → **speak**.
2. Else, if a spoken reply was built on a thought that has since moved and no
   new input has arrived → **correct**.
3. Else, if the user is typing, has been silent for `backchannel_after`, and the
   last backchannel is older than `backchannel_min_gap` → **backchannel**.
4. Else → **listen**.

Before releasing a draft it re-checks `is_stale`, drops stale drafts, and writes
back what it said (`mark_spoken`) so the state knows the floor is now free.

The policy is a pure function of a `View` dataclass, which is why
`tests/test_scheduler.py` can test it without a running engine.

## Backends (`llm.py`)

`complete(role, payload) -> JSON string`, with `role` in
`light` / `heavy` / `expression`.

* `MockBackend` — deterministic, offline; the reference implementation of the
  payload/response schema.
* `OpenAICompatBackend` — any OpenAI-compatible `/chat/completions` endpoint via
  `urllib`; no third-party dependency.

Prompt text for real models lives in `SYSTEM_PROMPTS`. Modules run backend calls
through `asyncio.to_thread` so a slow model call does not block the loops.

## Concurrency model

Single event loop, one coroutine per module. There is no lock on the state:
modules are asynchronous but never run concurrently inside a single write, and
all writes are short. `SharedState` calls listeners synchronously; a listener
only sets an `asyncio.Event`. If a host integrates the state from another thread,
it must marshal writes onto the loop (e.g. `loop.call_soon_threadsafe`).

Each module sleeps via `asyncio.wait_for(self._wake.wait(), idle_timeout)`, so a
module still ticks when nothing happens. That is what makes thinking continuous
rather than event-driven, and the `idle_timeout` is the knob that controls its
cost.

## Extension points

* `Memory` (phase 2): subscribe to the state, retrieve slowly, write results back
  as thoughts with `source="memory"`.
* `Self-monitoring` (phase 2): compare `spoken` with the latest confirmed
  thoughts and raise corrections instead of leaving it to the scheduler.
* Learned scheduler: replace `choose_action` with a scoring model over `View`;
  keep the release-time version check regardless of what proposes.
