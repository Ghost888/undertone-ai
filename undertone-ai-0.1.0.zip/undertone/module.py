"""The module base class: a coroutine that reacts to state versions.

Modules are woken by versions instead of calling each other. A module's step()
reads the state, decides, writes back, and returns; the next step runs when
somebody publishes a new version or after ``idle_timeout`` (which is what
makes continuous thinking actually continuous).
"""

from __future__ import annotations

import asyncio


class Module:
    name = "module"

    def __init__(self, state, config) -> None:
        self.state = state
        self.config = config
        self.idle_timeout = 0.2
        self._wake = asyncio.Event()
        self._stopping = False
        self._task = None
        state.subscribe(self._on_change)

    def _on_change(self, version: int) -> None:
        self._wake.set()

    async def step(self) -> None:  # pragma: no cover - abstract
        raise NotImplementedError

    async def _loop(self) -> None:
        while not self._stopping:
            self._wake.clear()
            try:
                await self.step()
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # keep the pipeline alive, record the fault
                self.state.audit.append((self.state.now(), "%s:error:%r" % (self.name, exc)))
            try:
                await asyncio.wait_for(self._wake.wait(), self.idle_timeout)
            except asyncio.TimeoutError:
                pass

    def start(self, loop) -> "asyncio.Task":
        self._task = loop.create_task(self._loop())
        return self._task

    async def stop(self) -> None:
        self._stopping = True
        if self._task is not None:
            self._task.cancel()
            await asyncio.gather(self._task, return_exceptions=True)
            self._task = None
