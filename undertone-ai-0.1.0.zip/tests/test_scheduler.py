import unittest

from undertone.scheduler import BACKCHANNEL, CORRECT, LISTEN, SPEAK, View, choose_action


class ChooseActionTests(unittest.TestCase):
    def test_speaks_only_when_a_reply_is_expected_and_a_draft_exists(self):
        self.assertEqual(choose_action(View(awaiting_reply=True, has_draft=True)), SPEAK)
        self.assertEqual(choose_action(View(awaiting_reply=True, has_draft=False)), LISTEN)
        self.assertEqual(choose_action(View(awaiting_reply=False, has_draft=True)), LISTEN)

    def test_backchannel_needs_typing_silence_and_a_gap(self):
        view = View(
            typing=True,
            silence=2.0,
            backchannel_gap=10.0,
            backchannel_after=1.4,
            backchannel_min_gap=3.5,
        )
        self.assertEqual(choose_action(view), BACKCHANNEL)

        view.backchannel_gap = 0.1
        self.assertEqual(choose_action(view), LISTEN)

        view.backchannel_gap = 10.0
        view.typing = False
        self.assertEqual(choose_action(view), LISTEN)

    def test_correction_beats_backchannel(self):
        view = View(
            correction_pending=True,
            typing=True,
            silence=5.0,
            backchannel_gap=10.0,
        )
        self.assertEqual(choose_action(view), CORRECT)

    def test_reply_beats_everything(self):
        view = View(awaiting_reply=True, has_draft=True, correction_pending=True)
        self.assertEqual(choose_action(view), SPEAK)


if __name__ == "__main__":
    unittest.main()
