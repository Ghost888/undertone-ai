import asyncio
import unittest

from undertone.config import Config
from undertone.engine import Engine


def fast_config(**overrides):
    config = Config(
        pause_after=0.25,
        typing_timeout=10.0,
        light_min_interval=0.0,
        deep_thought_cooldown=0.0,
        perception_tick=0.05,
        thinking_tick=0.05,
        scheduler_tick=0.05,
        tail_delay=0.8,
        proposal_max_age=30.0,
    )
    for key, value in overrides.items():
        setattr(config, key, value)
    return config


class EngineTests(unittest.IsolatedAsyncioTestCase):
    async def test_a_sent_message_eventually_gets_a_reply(self):
        engine = Engine(fast_config())
        async with engine:
            await engine.user_typing("How do I structure a README?")
            await asyncio.sleep(0.2)
            await engine.user_send("How do I structure a README?")
            await asyncio.sleep(1.2)

        replies = [line for line in engine.transcript.lines if line["kind"] == "reply"]
        self.assertTrue(replies, engine.transcript.render())
        self.assertEqual(engine.state.intent, "question")
        self.assertTrue(engine.state.spoken)

    async def test_a_long_pause_while_typing_triggers_a_backchannel(self):
        config = fast_config(backchannel_after=0.3, backchannel_min_gap=0.0, pause_after=0.15)
        engine = Engine(config)
        async with engine:
            await engine.user_typing("So the thing is")
            await asyncio.sleep(0.9)
            await engine.user_send("So the thing is this.")
            await asyncio.sleep(0.9)

        kinds = [line["kind"] for line in engine.transcript.lines]
        self.assertIn("backchannel", kinds, engine.transcript.render())

    async def test_input_during_typing_updates_the_understanding(self):
        engine = Engine(fast_config())
        async with engine:
            await engine.user_typing("Tell me about")
            await asyncio.sleep(0.25)
            await engine.user_typing("Tell me about the light layer")
            await asyncio.sleep(0.25)
            await engine.user_send("Tell me about the light layer.")
            await asyncio.sleep(0.8)

        self.assertIn("light layer", engine.state.understanding)
        self.assertTrue(engine.state.thoughts)


if __name__ == "__main__":
    unittest.main()
