"""Input events: the text-side "hearing" of Undertone.

A text conversation gives the system more than finished messages: keystrokes,
pauses, edits, the Enter key and interruptions. Those are the signals the
perception module turns into events on the shared state.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


class EventKind:
    """Event kinds, kept as plain strings so they serialize trivially."""

    TYPING = "typing"
    PAUSE = "pause"
    SEND = "send"
    INTERRUPT = "interrupt"
    EDIT = "edit"
    IDLE = "idle"


ALL_KINDS = (
    EventKind.TYPING,
    EventKind.PAUSE,
    EventKind.SEND,
    EventKind.INTERRUPT,
    EventKind.EDIT,
    EventKind.IDLE,
)


def kind_of(value: Any) -> str:
    """Normalize a kind given as a string or as an enum-ish value."""

    if isinstance(value, str):
        text = value.strip().lower()
    else:  # e.g. an enum member from a host application
        text = str(getattr(value, "value", value)).strip().lower()
    if text not in ALL_KINDS:
        raise ValueError("unknown event kind: %r" % (value,))
    return text


@dataclass
class InputEvent:
    """One observation from the input stream."""

    kind: str
    text: str = ""
    ts: float = field(default_factory=time.time)

    def __post_init__(self) -> None:
        self.kind = kind_of(self.kind)
        if self.text is None:
            self.text = ""

    def to_dict(self) -> dict:
        return {"kind": self.kind, "text": self.text, "ts": self.ts}

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return "InputEvent(%s, %r)" % (self.kind, self.text)
