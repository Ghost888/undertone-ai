"""Compare the parallel prototype with the turn-based baseline.

Run from the repository root:

    python experiments/compare.py
    python experiments/compare.py --scenario add-info --repeat 3

The mock backends are given a fixed latency so that the difference between
"think while the user types" and "think after the user finishes" is visible.
With real models (``--backend openai``) the same script measures real latency;
the numbers here are a smoke test of the harness, not a result.
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from undertone.config import Config  # noqa: E402
from undertone.engine import Engine  # noqa: E402
from undertone.events import EventKind, InputEvent, kind_of  # noqa: E402
from undertone.llm import MockBackend  # noqa: E402
from undertone.scenarios import SCENARIOS, load_script  # noqa: E402
from turn_based import TurnBasedBaseline  # noqa: E402

TIMEOUT = 15.0


async def _wait_for_reply(engine: Engine, start_index: int) -> float:
    """Seconds until an assistant reply appears after *start_index*."""

    started = time.perf_counter()
    while time.perf_counter() - started < TIMEOUT:
        for line in engine.transcript.lines[start_index:]:
            if line["speaker"] == "assistant" and line["kind"] == "reply":
                return time.perf_counter() - started
        await asyncio.sleep(0.02)
    return float("nan")


async def run_undertone(name: str, config: Config) -> dict:
    engine = Engine(config)
    latencies = []
    async with engine:
        for step in load_script(name):
            await asyncio.sleep(float(step.get("delay", 0.0)))
            kind = kind_of(step["kind"])
            text = step.get("text", "")
            if kind == EventKind.SEND:
                start_index = len(engine.transcript.lines)
                await engine.user_send(text)
                latencies.append(await _wait_for_reply(engine, start_index))
            elif kind == EventKind.INTERRUPT:
                await engine.user_interrupt(text)
            elif kind == EventKind.EDIT:
                await engine.user_edit(text)
            else:
                engine.feed(InputEvent(kind, text))
        await asyncio.sleep(config.tail_delay)

    transcripts = engine.transcript
    return {
        "scenario": name,
        "architecture": "parallel",
        "latencies": latencies,
        "replies": transcripts.count("assistant", "reply"),
        "backchannels": transcripts.count("assistant", "backchannel"),
        "corrections": transcripts.count("assistant", "correction"),
        "stale_drops": len([u for u in engine.state.dropped if u.note == "stale-thought"]),
        "thoughts": len(engine.state.thoughts),
        "dropped": len(engine.state.dropped),
    }


async def run_baseline(name: str, config: Config) -> dict:
    baseline = TurnBasedBaseline(
        MockBackend(latency=config.mock_latency),
        MockBackend(latency=config.mock_heavy_latency),
    )
    latencies = []
    replies = 0
    for step in load_script(name):
        await asyncio.sleep(float(step.get("delay", 0.0)))
        if step["kind"] == EventKind.SEND:
            _, latency = await baseline.respond(step.get("text", ""))
            latencies.append(latency)
            replies += 1
    return {
        "scenario": name,
        "architecture": "turn-based",
        "latencies": latencies,
        "replies": replies,
        "backchannels": 0,
        "corrections": 0,
        "stale_drops": 0,
        "thoughts": 0,
        "dropped": 0,
    }


def _mean(values):
    values = [v for v in values if v == v]  # drop NaN
    return sum(values) / len(values) if values else float("nan")


async def amain(args) -> int:
    config = Config(mock_latency=args.latency, mock_heavy_latency=args.heavy_latency, tail_delay=1.0)
    if args.backend:
        config.backend = args.backend
        config.base_url = args.base_url or config.base_url

    names = [args.scenario] if args.scenario else sorted(SCENARIOS)
    print("backend=%s light_latency=%.2fs heavy_latency=%.2fs repeat=%d" % (
        args.backend or "mock", args.latency, args.heavy_latency, args.repeat))
    print()
    header = "%-12s %-12s %8s %8s %6s %6s %6s" % (
        "scenario", "arch", "lat_mean", "lat_max", "reply", "backch", "stale")
    print(header)
    print("-" * len(header))

    for name in names:
        for _ in range(args.repeat):
            parallel = await run_undertone(name, config)
            baseline = await run_baseline(name, config)
            for result in (parallel, baseline):
                print("%-12s %-12s %8.3f %8.3f %6d %6d %6d" % (
                    result["scenario"],
                    result["architecture"],
                    _mean(result["latencies"]),
                    max(result["latencies"] or [float("nan")]),
                    result["replies"],
                    result["backchannels"],
                    result["stale_drops"],
                ))
        print()
    print("lat_* = seconds from the user pressing send to the first spoken token.")
    print("The parallel column pays thinking during typing; the turn-based column pays it after send.")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Compare parallel vs turn-based dialogue.")
    parser.add_argument("--scenario", default=None, help="scenario name (default: all)")
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--latency", type=float, default=0.25, help="mock light-model latency (s)")
    parser.add_argument("--heavy-latency", type=float, default=0.6, help="mock heavy-model latency (s)")
    parser.add_argument("--backend", default=None, help="mock (default) or openai")
    parser.add_argument("--base-url", default=None)
    args = parser.parse_args()
    return asyncio.run(amain(args))


if __name__ == "__main__":
    sys.exit(main())
