"""Scripted input streams used by the demo and the experiments.

Each step is ``{"delay": seconds, "kind": event kind, "text": ...}``. The delays
are what make "thinking during input" observable: between two typing events the
light layer has time to work.
"""

from __future__ import annotations

from typing import Dict, List

from .events import kind_of

SCENARIOS: Dict[str, List[dict]] = {
    # 1. the user keeps adding information while typing
    "add-info": [
        {"delay": 0.02, "kind": "typing", "text": "How do I"},
        {"delay": 0.35, "kind": "typing", "text": "How do I structure"},
        {"delay": 0.35, "kind": "typing", "text": "How do I structure a README"},
        {"delay": 1.00, "kind": "typing", "text": "How do I structure a README for a research prototype?"},
        {"delay": 0.30, "kind": "send", "text": "How do I structure a README for a research prototype?"},
    ],
    # 2. the user changes their mind midway through typing
    "change-mind": [
        {"delay": 0.02, "kind": "typing", "text": "Explain the scheduler"},
        {"delay": 0.50, "kind": "typing", "text": "Explain the scheduler as a blackboard"},
        {"delay": 0.50, "kind": "edit", "text": "Explain the scheduler as a turn-taking policy"},
        {"delay": 0.30, "kind": "send", "text": "Explain the scheduler as a turn-taking policy."},
        {"delay": 2.20, "kind": "typing", "text": "Actually, keep it short"},
        {"delay": 0.40, "kind": "send", "text": "Actually, keep it short."},
    ],
    # 3. a long answer interrupted by a follow-up
    "interrupt": [
        {"delay": 0.02, "kind": "typing", "text": "Walk me through the thinking layers"},
        {"delay": 0.30, "kind": "send", "text": "Walk me through the thinking layers."},
        {"delay": 1.80, "kind": "interrupt", "text": "Wait, only the light layer"},
    ],
}


def load_script(name: str) -> List[dict]:
    """Return a normalized copy of a scenario."""

    if name not in SCENARIOS:
        raise KeyError("unknown scenario %r (known: %s)" % (name, ", ".join(sorted(SCENARIOS))))
    script = []
    for step in SCENARIOS[name]:
        entry = dict(step)
        entry["kind"] = kind_of(entry["kind"])
        entry.setdefault("text", "")
        script.append(entry)
    return script
