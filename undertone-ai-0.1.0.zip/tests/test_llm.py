import unittest

from undertone.llm import MockBackend, looks_like_question, parse_json


class ParseJsonTests(unittest.TestCase):
    def test_plain_json(self):
        self.assertEqual(parse_json('{"text": "hi"}'), {"text": "hi"})

    def test_fenced_json(self):
        raw = '```json\n{"text": "hi"}\n```'
        self.assertEqual(parse_json(raw), {"text": "hi"})

    def test_chatter_around_json(self):
        raw = 'Sure. {"text": "hi"} Hope that helps.'
        self.assertEqual(parse_json(raw), {"text": "hi"})

    def test_garbage(self):
        self.assertIsNone(parse_json("not json at all"))
        self.assertIsNone(parse_json(""))


class MockBackendTests(unittest.TestCase):
    def setUp(self):
        self.backend = MockBackend()

    def test_light_layer_returns_the_contract(self):
        payload = {
            "understanding": "",
            "intent": "answer",
            "thoughts": [],
            "events": [{"kind": "send", "text": "How do I write a README?"}],
            "last_user_text": "How do I write a README?",
        }
        delta = parse_json(self.backend.complete("light", payload))
        self.assertIsNotNone(delta)
        self.assertEqual(delta["intent"], "question")
        self.assertTrue(delta["needs_deep_thought"])
        self.assertTrue(delta["thoughts"])

    def test_heavy_layer_confirms_a_thought(self):
        delta = parse_json(
            self.backend.complete(
                "heavy",
                {"understanding": "the user asks about a README", "intent": "question", "thoughts": []},
            )
        )
        self.assertEqual(delta["confidence"], "confirmed")
        self.assertIn("README", delta["thought"])

    def test_expression_layer_returns_text(self):
        delta = parse_json(
            self.backend.complete(
                "expression",
                {"understanding": "the user asks about a README", "intent": "question", "thoughts": []},
            )
        )
        self.assertTrue(delta["text"])

    def test_question_detection(self):
        self.assertTrue(looks_like_question("How do I build this?"))
        self.assertTrue(looks_like_question("真的吗"))
        self.assertFalse(looks_like_question("Sounds good"))


if __name__ == "__main__":
    unittest.main()
