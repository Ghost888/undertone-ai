"""The baseline: today's turn-based dialogue loop.

Wait for the finished message, then think, then speak, in one shot. Same
backends, same prompts, no shared state, no thinking during input. This is what
the parallel architecture has to beat on latency and naturalness.
"""

from __future__ import annotations

import asyncio
import time
from typing import Tuple

from undertone.llm import parse_json


class TurnBasedBaseline:
    def __init__(self, light_backend, heavy_backend) -> None:
        self.light_backend = light_backend
        self.heavy_backend = heavy_backend

    async def respond(self, text: str) -> Tuple[str, float]:
        """Return (what it says, latency in seconds) for one finished message."""

        started = time.perf_counter()
        light = parse_json(await asyncio.to_thread(self.light_backend.complete, "light", {
            "role": "light",
            "understanding": "",
            "intent": "answer",
            "thoughts": [],
            "events": [{"kind": "send", "text": text}],
            "last_user_text": text,
        })) or {}

        understanding = str(light.get("understanding") or text)
        intent = str(light.get("intent") or "answer")
        tentative = [
            {"id": "light:%d" % index, "text": str(item.get("text") or ""), "confidence": "tentative"}
            for index, item in enumerate(light.get("thoughts") or [])
        ]

        heavy = parse_json(await asyncio.to_thread(self.heavy_backend.complete, "heavy", {
            "role": "heavy",
            "understanding": understanding,
            "intent": intent,
            "thoughts": tentative,
            "last_user_text": text,
        })) or {}

        confirmed = [
            {
                "id": "heavy:plan",
                "text": str(heavy.get("thought") or understanding),
                "confidence": "confirmed",
            }
        ]

        expression = parse_json(await asyncio.to_thread(self.light_backend.complete, "expression", {
            "role": "expression",
            "understanding": understanding,
            "intent": intent,
            "thoughts": confirmed,
        })) or {}

        text_out = str(expression.get("text") or "")
        return text_out, time.perf_counter() - started
