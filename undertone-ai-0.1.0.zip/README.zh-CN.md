# Undertone

[English](README.md) | **简体中文**

> 边打边想。面向实时文本对话的并行思考架构。

**状态：概念阶段（草稿），附带可运行的骨架。** 本仓库包含研究概念、实验设计，以及一个离线即可运行的原型骨架：带版本的共享状态、感知、两层思考、表达，以及唯一拥有发言权的规则式调度器。目前还没有实验结果，运行也不需要模型。欢迎批评、相关工作总结与原型贡献。

---

## 快速开始

需要 Python 3.10+，无第三方依赖，也不需要 API key：内置的 `mock` 后端是确定性的离线替身。

```bash
python -m undertone demo --scenario add-info   # 回放一段脚本化对话
python -m undertone scenarios                  # 列出内置脚本
python -m undertone chat                       # 在终端里与它对话
python -m unittest discover -s tests -v        # 运行测试
python experiments/compare.py                  # 并行架构 vs 轮次式基线
```

接真实模型时，任何 OpenAI 兼容端点都可以（vLLM、Ollama、llama.cpp server、OpenAI）：

```bash
export OPENAI_API_KEY=sk-...
python -m undertone demo --scenario interrupt \
  --backend openai --base-url http://localhost:8000/v1 \
  --light-model qwen2.5-7b-instruct --heavy-model qwen2.5-72b-instruct
```

脚本跑完会打印对话，然后打印最终状态：当前理解、思考、已说出的内容，以及那些**因为所依赖的思考已经变化而被丢弃**的草稿——这是设计里最容易观察、也最难做对的部分。

## 目录结构

```
undertone/            # 原型包
  state.py            # 带版本的共享状态（模块之间唯一的通道）
  events.py           # typing / pause / send / interrupt / edit
  perception.py       # 输入流 -> 事件
  thinking/light.py   # 常开轻层：增量理解、试探性思考
  thinking/heavy.py   # 按需重层：确认性思考
  expression.py       # 只提出候选发言，不能直接输出
  scheduler.py        # 唯一出口；规则式轮流政策 + 发言前版本检查
  llm.py              # mock 后端 + OpenAI 兼容后端
  engine.py           # 装配、生命周期、脚本回放
  scenarios.py        # 脚本化输入流
  cli.py              # `python -m undertone`
docs/                 # 架构与设计笔记
experiments/          # 轮次式基线与对比脚本
tests/                # 单元测试与集成测试
```

架构细节见 [docs/architecture.md](docs/architecture.md)，这个骨架刻意没做的事见 [docs/design-notes.md](docs/design-notes.md)。完整的概念、假设（H1–H4）、相关工作与评测计划请读 [英文 README](README.md)。

## 核心想法

把「思考」和「说话」分开，让一个**持续运行的思考过程**贯穿整段对话。模块之间互不直接调用，只读写**带版本的共享状态**；只有**调度器**拥有输出权。

期望的体验：

- 你话说一半停顿时，它说一句「嗯…」，表示在听，但不抢话。
- 你还没说完，它已经在推算你的意思。
- 回答到一半想到新东西，它补充或说「更正一下」。
- 你打断它，它立刻停下，并把你的新话并入原有思路，而不是推倒重来。

## 四个假设

| 编号 | 假设 |
|---|---|
| **H1** | 输入期思考：用户打字时就增量理解、预先思考，能降低响应延迟、提升相关性 |
| **H2** | 持续更新与续接：在新输入或打断时更新既有思考而非重新生成，打断后的连贯性更好 |
| **H3** | 当场更正：思考更新使已说内容过期时，「更正：……」优于沉默或硬说完 |
| **H4** | 连续性本身有价值：不依赖输入事件的常开思考，比纯事件驱动更自然 |

## 评测计划

- 同基座模型下，**轮次式** vs **并行架构**（`experiments/turn_based.py` vs `experiments/compare.py`）
- 逐个消融 H1–H4 对应组件；去掉后自然度没有下降的组件就是过度设计
- 指标：响应延迟、打断后连贯性、更正质量、主观自然度（成对偏好）、额外 token 与延迟成本
- 三个初始场景：打字中不断补充信息（`add-info`）、中途改变主意（`change-mind`）、长回答被打断（`interrupt`）

## 这不是什么

- 不是让模型更聪明，而是让它更像「在场」。
- 不是大脑复刻，模块划分只是组织职责的类比。
- 不是新发明的架构：黑板系统与轮流机制都来自前人的工作。
- 第一阶段不依赖语音。

## 路线图

- [x] **骨架**：共享状态、感知、轻重两层思考、表达、规则式调度、mock 后端、测试
- [ ] **文献核实**：细读相关工作，修正边界
- [ ] **第一阶段原型**：用真实模型替掉 mock 提示词，在三个场景上测量
- [ ] **基线实验**：轮次式 vs 并行
- [ ] **消融与成本分析**：检验 H1–H4，决定组件去留
- [ ] **第二阶段**：记忆与自我监控
- [ ] **扩展**：评估向语音扩展

## 参与

目前最有帮助的是：相关工作的补充与纠错、更可靠的「在场感」评测方法、常开轻层的具体实现方案。欢迎 Issue 或 Pull Request；提交代码前请先跑 `python -m unittest discover -s tests`。

## 许可

待定 (TBD)。
