"""Expression: proposes what to say, and has no right to say it.

It reads confirmed thoughts from the state and drafts one candidate utterance.
The draft carries the versions of the thoughts it used, so the scheduler can
tell whether it is still valid by the time the floor opens.

Drafting is also part of the cost budget: while nobody is talking and nothing is
owed, the layer stays quiet instead of re-drafting forever.
"""

from __future__ import annotations

import asyncio

from ..llm import parse_json
from ..module import Module
from ..state import Utterance


class Expression(Module):
    name = "expression"

    def __init__(self, state, backend, config) -> None:
        super().__init__(state, config)
        self.backend = backend
        self.idle_timeout = config.thinking_tick
        self._snapshot = None
        self.proposals = 0

    async def step(self) -> None:
        confirmed = self.state.confirmed_thoughts()
        if not confirmed:
            return
        snapshot = {t.id: t.version for t in confirmed}
        valid_drafts = [u for u in self.state.pending if not self.state.is_stale(u)]
        if snapshot == self._snapshot and valid_drafts:
            return

        awaiting_reply = (self.state.get_signal("last_send", 0.0) or 0.0) > (
            self.state.get_signal("last_spoken", 0.0) or 0.0
        )
        typing = (self.state.get_signal("typing", 0.0) or 0.0) > 0.5
        if not awaiting_reply and not typing:
            # nobody is talking and nothing is owed: keep the thoughts, save the call
            self._snapshot = snapshot
            return

        payload = {
            "role": "expression",
            "understanding": self.state.understanding,
            "intent": self.state.intent,
            "thoughts": [t.to_dict() for t in confirmed],
        }
        raw = await asyncio.to_thread(self.backend.complete, "expression", payload)
        delta = parse_json(raw) or {}
        text = str(delta.get("text") or "").strip()
        if not text:
            return

        self._snapshot = snapshot
        self.proposals += 1
        self.state.propose(
            Utterance(
                text=text,
                kind="reply",
                based_on_version=self.state.version,
                thought_versions=dict(snapshot),
                ts=self.state.now(),
            )
        )
        self.state.trim_pending(self.config.max_pending)
