"""Engine: wires the modules together and runs the input stream.

The engine owns no dialogue logic. It constructs the blackboard, hands every
module the same state, starts their loops, and forwards input events from the
host application (or a script) to perception.
"""

from __future__ import annotations

import asyncio
from typing import List, Optional

from .config import Config
from .events import EventKind, InputEvent, kind_of
from .expression import Expression
from .llm import make_backend
from .module import Module
from .perception import Perception
from .scheduler import Scheduler
from .state import SharedState
from .thinking import HeavyThinker, LightThinker
from .transcript import Transcript


class Engine:
    def __init__(
        self,
        config: Optional[Config] = None,
        backend=None,
        transcript: Optional[Transcript] = None,
    ) -> None:
        self.config = config or Config()
        self.state = SharedState()
        self.transcript = transcript or Transcript()

        light_backend = backend or make_backend(self.config, "light")
        heavy_backend = backend or make_backend(self.config, "heavy")

        self.perception = Perception(self.state, self.config)
        self.light = LightThinker(self.state, light_backend, self.config)
        self.heavy = HeavyThinker(self.state, heavy_backend, self.config)
        self.expression = Expression(self.state, light_backend, self.config)
        self.scheduler = Scheduler(self.state, self.config, self.transcript)
        self._modules: List[Module] = [
            self.perception,
            self.light,
            self.heavy,
            self.expression,
            self.scheduler,
        ]
        self._started = False

    # -- lifecycle ---------------------------------------------------------
    async def start(self) -> "Engine":
        if self._started:
            return self
        loop = asyncio.get_event_loop()
        for module in self._modules:
            module.start(loop)
        self._started = True
        return self

    async def stop(self) -> None:
        if not self._started:
            return
        for module in self._modules:
            await module.stop()
        self._started = False

    async def __aenter__(self) -> "Engine":
        return await self.start()

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.stop()

    # -- input -------------------------------------------------------------
    def feed(self, event: InputEvent) -> None:
        self.perception.feed(event)

    async def user_typing(self, text: str) -> None:
        self.feed(InputEvent(EventKind.TYPING, text))

    async def user_edit(self, text: str) -> None:
        self.feed(InputEvent(EventKind.EDIT, text))

    async def user_send(self, text: str) -> None:
        self.transcript.emit("user", text, "send", ts=self.state.now())
        self.feed(InputEvent(EventKind.SEND, text))

    async def user_interrupt(self, text: str) -> None:
        self.transcript.emit("user", text, "interrupt", ts=self.state.now())
        self.feed(InputEvent(EventKind.INTERRUPT, text))

    async def run_script(self, script: List[dict]) -> None:
        """Replay a scenario and leave the engine running for tail_delay."""

        for step in script:
            await asyncio.sleep(float(step.get("delay", 0.0)))
            kind = kind_of(step.get("kind", EventKind.TYPING))
            text = str(step.get("text") or "")
            if kind == EventKind.SEND:
                await self.user_send(text)
            elif kind == EventKind.INTERRUPT:
                await self.user_interrupt(text)
            elif kind == EventKind.EDIT:
                await self.user_edit(text)
            else:
                self.feed(InputEvent(kind, text))
        await asyncio.sleep(float(self.config.tail_delay))

    # -- inspection --------------------------------------------------------
    def report(self) -> dict:
        state = self.state
        return {
            "version": state.version,
            "understanding": state.understanding,
            "intent": state.intent,
            "thoughts": len(state.thoughts),
            "confirmed": len(state.confirmed_thoughts()),
            "pending": len(state.pending),
            "spoken": len(state.spoken),
            "dropped": len(state.dropped),
            "events": len(state.input_events),
            "light_runs": self.light.calls,
            "heavy_runs": self.heavy.runs,
            "proposals": self.expression.proposals,
        }
