"""The two thinking layers: always-on light, on-demand heavy."""

from .light import LightThinker
from .heavy import HeavyThinker

__all__ = ["LightThinker", "HeavyThinker"]
