"""Perception: turn keystrokes, pauses, sends and interruptions into events.

Nothing is interpreted here. Perception only answers "what just happened in the
input stream", which is the text-side equivalent of hearing someone.
"""

from __future__ import annotations

import asyncio

from .module import Module
from .events import EventKind, InputEvent


class Perception(Module):
    name = "perception"

    def __init__(self, state, config) -> None:
        super().__init__(state, config)
        self.idle_timeout = config.perception_tick
        self._inbox = asyncio.Queue()
        self._typing = False
        self._typing_ts = 0.0
        self._typing_text = ""
        self._pause_pending = False

    # -- input stream ------------------------------------------------------
    def feed(self, event: InputEvent) -> None:
        """Called by the host application / script, never by another module."""

        self._inbox.put_nowait(event)

    # -- module loop -------------------------------------------------------
    async def step(self) -> None:
        while True:
            try:
                event = self._inbox.get_nowait()
            except asyncio.QueueEmpty:
                break
            self._handle(event)
        self._debounce()

    def _handle(self, event: InputEvent) -> None:
        state = self.state
        now = state.now()
        if event.kind == EventKind.TYPING:
            self._typing = True
            self._typing_ts = now
            if event.text:
                self._typing_text = event.text
            self._pause_pending = True
            state.set_signal("typing", 1.0)
            if event.text:
                state.append_event(InputEvent(event.kind, event.text, ts=now))
            return
        if event.kind == EventKind.PAUSE:
            self._pause_pending = False
            state.append_event(InputEvent(event.kind, self._typing_text, ts=now))
            return
        if event.kind == EventKind.SEND:
            self._typing = False
            self._pause_pending = False
            state.set_signal("typing", 0.0)
            state.set_signal("last_send", now)
            self._typing_text = ""
            state.append_event(InputEvent(event.kind, event.text, ts=now))
            return
        if event.kind == EventKind.INTERRUPT:
            self._typing = False
            self._pause_pending = False
            state.set_signal("typing", 0.0)
            state.set_signal("last_interrupt", now)
            state.append_event(InputEvent(event.kind, event.text, ts=now))
            return
        state.append_event(InputEvent(event.kind, event.text, ts=now))

    def _debounce(self) -> None:
        """Infer a PAUSE when someone types and then falls silent."""

        if not self._typing:
            return
        now = self.state.now()
        idle = now - self._typing_ts
        if self._pause_pending and idle >= self.config.pause_after:
            self._pause_pending = False
            self.state.append_event(InputEvent(EventKind.PAUSE, self._typing_text, ts=now))
        elif idle >= self.config.typing_timeout:
            self._typing = False
            self.state.set_signal("typing", 0.0)
