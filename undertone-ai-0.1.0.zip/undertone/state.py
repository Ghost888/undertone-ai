"""The versioned shared state, the only channel between modules.

Design rules encoded here (see README and docs/architecture.md):

* modules never call each other; they read and write this blackboard;
* every write bumps a global version and wakes the listeners;
* a thought carries the version at which it was last written;
* an utterance records the versions of the thoughts it depends on, and the
  scheduler refuses to speak it if any of them has moved since (stale content
  is dropped or corrected instead of blindly finished).
"""

from __future__ import annotations

import itertools
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional


class Confidence:
    """Thought confidence. Tentative thoughts may never reach the output."""

    TENTATIVE = "tentative"
    CONFIRMED = "confirmed"


def as_confidence(value) -> str:
    if isinstance(value, str):
        text = value.strip().lower()
    else:
        text = str(getattr(value, "value", value)).strip().lower()
    return Confidence.CONFIRMED if text == "confirmed" else Confidence.TENTATIVE


@dataclass
class Thought:
    """One record of "what I currently think"."""

    id: str
    text: str
    confidence: str = Confidence.TENTATIVE
    version: int = 0
    source: str = "light"
    ts: float = 0.0

    def __post_init__(self) -> None:
        self.confidence = as_confidence(self.confidence)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "text": self.text,
            "confidence": self.confidence,
            "version": self.version,
            "source": self.source,
        }


@dataclass
class Utterance:
    """A candidate thing to say, or a thing already said."""

    text: str
    kind: str = "reply"
    """reply | backchannel | correction"""

    based_on_version: int = 0
    thought_versions: Dict[str, int] = field(default_factory=dict)
    ts: float = 0.0
    note: str = ""

    def to_dict(self) -> dict:
        return {
            "text": self.text,
            "kind": self.kind,
            "based_on_version": self.based_on_version,
            "thought_versions": dict(self.thought_versions),
            "ts": self.ts,
            "note": self.note,
        }


class SharedState:
    """A blackboard with monotonically increasing versions."""

    def __init__(self, clock: Optional[Callable[[], float]] = None) -> None:
        self._clock = clock or time.time
        self._version = 0
        self._ids = itertools.count(1)
        self._listeners: List[Callable[[int], None]] = []

        # --- records -----------------------------------------------------
        self.input_events: List = []          # List[InputEvent]
        self.understanding: str = ""
        self.intent: str = "answer"
        self.thoughts: Dict[str, Thought] = {}
        self.pending: List[Utterance] = []    # drafts waiting for the floor
        self.spoken: List[Utterance] = []
        self.dropped: List[Utterance] = []

        # --- cheap side channels -----------------------------------------
        self.signals: Dict[str, float] = {}
        self.audit: List = []                 # List[(ts, note)]
        self.needs_deep_thought: bool = False

    # -- clock / ids ------------------------------------------------------
    def now(self) -> float:
        return float(self._clock())

    def new_id(self, prefix: str = "t") -> str:
        return "%s%d" % (prefix, next(self._ids))

    # -- listeners --------------------------------------------------------
    def subscribe(self, listener: Callable[[int], None]) -> None:
        if listener not in self._listeners:
            self._listeners.append(listener)

    def unsubscribe(self, listener: Callable[[int], None]) -> None:
        if listener in self._listeners:
            self._listeners.remove(listener)

    def _publish(self, note: str = "") -> int:
        self._version += 1
        if note:
            self.audit.append((self.now(), note))
            if len(self.audit) > 2000:
                del self.audit[:500]
        for listener in list(self._listeners):
            listener(self._version)
        return self._version

    @property
    def version(self) -> int:
        return self._version

    # -- input events -----------------------------------------------------
    def append_event(self, event) -> int:
        self.input_events.append(event)
        self.signals["last_input"] = float(event.ts)
        return self._publish("event:%s" % event.kind)

    def last_event(self, kinds: Optional[List[str]] = None):
        for event in reversed(self.input_events):
            if kinds is None or event.kind in kinds:
                return event
        return None

    def silence(self) -> float:
        """Seconds since the last input event (infinite when there is none)."""

        last = self.signals.get("last_input")
        if last is None:
            return float("inf")
        return max(0.0, self.now() - last)

    # -- understanding ----------------------------------------------------
    def set_understanding(self, text: str) -> int:
        text = (text or "").strip()
        if text == self.understanding:
            return self._version
        self.understanding = text
        return self._publish("understanding")

    def set_intent(self, intent: str) -> int:
        intent = (intent or "").strip() or "answer"
        if intent == self.intent:
            return self._version
        self.intent = intent
        return self._publish("intent:%s" % intent)

    # -- thoughts ---------------------------------------------------------
    def upsert_thought(
        self,
        key: str,
        text: str,
        confidence: str = Confidence.TENTATIVE,
        source: str = "light",
    ) -> Thought:
        """Write a thought incrementally.

        If the content is unchanged the thought is returned untouched and the
        version does not move: an idempotent re-think must not invalidate
        drafts that were based on it.
        """

        text = (text or "").strip()
        confidence = as_confidence(confidence)
        existing = self.thoughts.get(key)
        if existing is not None and existing.text == text and existing.confidence == confidence:
            return existing
        version = self._publish("thought:%s" % key)
        if existing is None:
            thought = Thought(
                id=key,
                text=text,
                confidence=confidence,
                version=version,
                source=source,
                ts=self.now(),
            )
            self.thoughts[key] = thought
            return thought
        existing.text = text
        existing.confidence = confidence
        existing.version = version
        existing.source = source
        existing.ts = self.now()
        return existing

    def confirmed_thoughts(self) -> List[Thought]:
        return [t for t in self.thoughts.values() if t.confidence == Confidence.CONFIRMED]

    def thought_versions(self) -> Dict[str, int]:
        return {t.id: t.version for t in self.thoughts.values()}

    def request_deep_thought(self, reason: str = "") -> int:
        if self.needs_deep_thought:
            return self._version
        self.needs_deep_thought = True
        return self._publish("deep-thought:%s" % (reason or "light"))

    # -- staleness ---------------------------------------------------------
    def is_stale(self, utterance: Utterance) -> bool:
        """True when a thought the utterance relied on has moved since."""

        for thought_id, version in utterance.thought_versions.items():
            thought = self.thoughts.get(thought_id)
            if thought is None or thought.version != version:
                return True
        return False

    # -- proposals / spoken ------------------------------------------------
    def propose(self, utterance: Utterance) -> int:
        if not utterance.ts:
            utterance.ts = self.now()
        self.pending.append(utterance)
        return self._publish("propose:%s" % utterance.kind)

    def take_pending(self, accept: Optional[Callable[[Utterance], bool]] = None) -> Optional[Utterance]:
        """Remove and return the newest acceptable, non-stale draft."""

        best = None
        for utterance in list(self.pending):
            if self.is_stale(utterance):
                self.drop_pending(utterance, "stale-thought")
                continue
            if accept is not None and not accept(utterance):
                continue
            if best is None or utterance.ts >= best.ts:
                best = utterance
        if best is not None:
            self.pending.remove(best)
        return best

    def drop_pending(self, utterance: Utterance, reason: str) -> int:
        if utterance not in self.pending:
            return self._version
        self.pending.remove(utterance)
        utterance.note = reason
        self.dropped.append(utterance)
        return self._publish("drop:%s" % reason)

    def trim_pending(self, limit: int) -> None:
        """Keep at most *limit* drafts, dropping the coldest first."""

        while len(self.pending) > max(0, limit):
            oldest = min(self.pending, key=lambda u: u.ts)
            self.drop_pending(oldest, "queue-full")

    def mark_spoken(self, utterance: Utterance) -> int:
        if not utterance.ts:
            utterance.ts = self.now()
        self.spoken.append(utterance)
        self.signals["last_spoken"] = self.now()
        return self._publish("speak:%s" % utterance.kind)

    # -- signals / snapshots ------------------------------------------------
    def set_signal(self, name: str, value: float) -> None:
        """Cheap flags that should not invalidate thoughts."""

        self.signals[name] = float(value)

    def get_signal(self, name: str, default: Optional[float] = None) -> Optional[float]:
        return self.signals.get(name, default)

    def snapshot(self) -> dict:
        return {
            "version": self._version,
            "understanding": self.understanding,
            "intent": self.intent,
            "thoughts": {k: t.to_dict() for k, t in self.thoughts.items()},
            "pending": [u.to_dict() for u in self.pending],
            "spoken": [u.to_dict() for u in self.spoken],
            "dropped": [u.to_dict() for u in self.dropped],
            "needs_deep_thought": self.needs_deep_thought,
            "signals": dict(self.signals),
        }
