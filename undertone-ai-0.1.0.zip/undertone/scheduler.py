"""The scheduler: the only module allowed to speak.

Phase 1 keeps it explicitly rule-based (see README, "Challenges and risks").
The rules are small on purpose so their contribution can be ablated against a
learned policy later. Before anything is released, the scheduler checks whether
the thoughts the draft was built on are still current; stale drafts are dropped
and, if they were already spoken, a correction may follow.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

from .module import Module
from .state import Thought, Utterance

LISTEN = "listen"
SPEAK = "speak"
BACKCHANNEL = "backchannel"
CORRECT = "correct"

BACKCHANNELS = ("mm...", "go on.", "I'm here.")


@dataclass
class View:
    """Everything the turn-taking policy is allowed to look at."""

    awaiting_reply: bool = False
    has_draft: bool = False
    correction_pending: bool = False
    typing: bool = False
    silence: float = 0.0
    backchannel_gap: float = 0.0
    backchannel_after: float = 1.4
    backchannel_min_gap: float = 3.5


def choose_action(view: View) -> str:
    """The turn-taking policy. Pure, so it can be unit-tested and swapped."""

    if view.awaiting_reply and view.has_draft:
        return SPEAK
    if view.correction_pending:
        return CORRECT
    if (
        view.typing
        and view.silence >= view.backchannel_after
        and view.backchannel_gap >= view.backchannel_min_gap
    ):
        return BACKCHANNEL
    return LISTEN


class Scheduler(Module):
    name = "scheduler"

    def __init__(self, state, config, transcript) -> None:
        super().__init__(state, config)
        self.transcript = transcript
        self.idle_timeout = config.scheduler_tick
        self._corrected = set()
        self._backchannel_index = 0
        self.actions = []

    async def step(self) -> None:
        state = self.state
        now = state.now()

        # 1. reaping: drop drafts whose thoughts moved, or that went cold
        for utterance in list(state.pending):
            if state.is_stale(utterance):
                state.drop_pending(utterance, "stale-thought")
            elif now - utterance.ts > self.config.proposal_max_age:
                state.drop_pending(utterance, "too-old")
        state.trim_pending(self.config.max_pending)

        # 2. read the little that the policy needs
        last_send = state.get_signal("last_send", 0.0) or 0.0
        last_spoken = state.get_signal("last_spoken", 0.0) or 0.0
        awaiting_reply = last_send > last_spoken
        drafts = [u for u in state.pending if u.kind == "reply" and not state.is_stale(u)]
        corrections = self._corrections_due(awaiting_reply)

        view = View(
            awaiting_reply=awaiting_reply,
            has_draft=bool(drafts),
            correction_pending=bool(corrections),
            typing=(state.get_signal("typing", 0.0) or 0.0) > 0.5,
            silence=state.silence(),
            backchannel_gap=now - (state.get_signal("last_backchannel", now) or now),
            backchannel_after=self.config.backchannel_after,
            backchannel_min_gap=self.config.backchannel_min_gap,
        )
        action = choose_action(view)
        self.actions.append(action)

        if action == SPEAK:
            draft = state.take_pending(lambda u: u.kind == "reply")
            if draft is not None:
                self._release(draft.text, "reply")
                state.mark_spoken(draft)
        elif action == CORRECT:
            thought = corrections[0]
            self._corrected.add((thought.id, thought.version))
            utterance = Utterance(
                text="Correction: " + thought.text,
                kind="correction",
                based_on_version=state.version,
                thought_versions={t.id: t.version for t in corrections},
                ts=now,
            )
            self._release(utterance.text, "correction")
            state.mark_spoken(utterance)
        elif action == BACKCHANNEL:
            text = BACKCHANNELS[self._backchannel_index % len(BACKCHANNELS)]
            self._backchannel_index += 1
            utterance = Utterance(
                text=text,
                kind="backchannel",
                based_on_version=state.version,
                thought_versions={},
                ts=now,
            )
            self._release(text, "backchannel")
            state.mark_spoken(utterance)
            state.set_signal("last_backchannel", now)

    # -- helpers -----------------------------------------------------------
    def _release(self, text: str, kind: str) -> None:
        self.transcript.emit("assistant", text, kind, ts=self.state.now())

    def _corrections_due(self, awaiting_reply: bool) -> List[Thought]:
        """Thoughts that moved after we spoke them, with no new input since."""

        if awaiting_reply:
            return []
        state = self.state
        last_send = state.get_signal("last_send", 0.0) or 0.0
        for utterance in reversed(state.spoken):
            if utterance.kind != "reply":
                continue
            if utterance.ts < last_send:
                return []
            changed: List[Thought] = []
            for thought_id, version in utterance.thought_versions.items():
                thought = state.thoughts.get(thought_id)
                if thought is None or thought.version == version:
                    continue
                if (thought.id, thought.version) in self._corrected:
                    continue
                changed.append(thought)
            return changed
        return []
