"""The always-on light layer.

It never stops: every new event triggers an incremental update of the
understanding and of the tentative thoughts, even when nobody is waiting for an
answer. It is cheap by construction (small model, deltas instead of rewrites)
and it decides when something deserves the heavy layer.
"""

from __future__ import annotations

import asyncio
from typing import List

from ..events import InputEvent
from ..llm import parse_json
from ..module import Module
from ..state import Confidence


def last_text(events: List[InputEvent], state) -> str:
    for event in reversed(events):
        if event.text:
            return event.text
    previous = state.last_event()
    return previous.text if previous is not None else ""


class LightThinker(Module):
    name = "light"

    def __init__(self, state, backend, config) -> None:
        super().__init__(state, config)
        self.backend = backend
        self.idle_timeout = config.thinking_tick
        self._seen = 0
        self._last_call = 0.0
        self.calls = 0

    async def step(self) -> None:
        events = self.state.input_events
        new_events = events[self._seen:]
        if not new_events:
            return
        now = self.state.now()
        if now - self._last_call < self.config.light_min_interval:
            return
        self._seen = len(events)
        self._last_call = now
        self.calls += 1

        payload = {
            "role": "light",
            "understanding": self.state.understanding,
            "intent": self.state.intent,
            "thoughts": [t.to_dict() for t in self.state.thoughts.values()],
            "events": [{"kind": e.kind, "text": e.text} for e in new_events],
            "last_user_text": last_text(new_events, self.state),
        }
        raw = await asyncio.to_thread(self.backend.complete, "light", payload)
        delta = parse_json(raw) or {}

        understanding = str(delta.get("understanding") or "").strip()
        if understanding:
            self.state.set_understanding(understanding)
        intent = str(delta.get("intent") or "").strip()
        if intent:
            self.state.set_intent(intent)

        for index, item in enumerate(delta.get("thoughts") or []):
            if not isinstance(item, dict):
                continue
            text = str(item.get("text") or "").strip()
            if not text:
                continue
            key = str(item.get("id") or "light:%d" % index)
            # the light layer proposes; it never has the right to confirm
            self.state.upsert_thought(key, text, Confidence.TENTATIVE, source="light")

        if delta.get("needs_deep_thought"):
            self.state.request_deep_thought("light")
