"""Command line entry point: ``python -m undertone <command>``.

Commands
--------
demo [--scenario NAME]   replay a scripted conversation and print the transcript
chat                     talk to it from the terminal (each line is one send)
scenarios                list the bundled scenarios
"""

from __future__ import annotations

import argparse
import asyncio
import os
import sys

from .config import Config
from .engine import Engine
from .scenarios import SCENARIOS, load_script


def _config_from_args(args) -> Config:
    config = Config()
    if getattr(args, "backend", None):
        config.backend = args.backend
    if getattr(args, "base_url", None):
        config.base_url = args.base_url
    if getattr(args, "light_model", None):
        config.light_model = args.light_model
    if getattr(args, "heavy_model", None):
        config.heavy_model = args.heavy_model
    if getattr(args, "api_key", None):
        config.api_key = args.api_key
    elif os.environ.get("OPENAI_API_KEY"):
        config.api_key = os.environ["OPENAI_API_KEY"]
    return config


def _print_report(engine: Engine) -> None:
    report = engine.report()
    print()
    print("--- state ---")
    for key in (
        "understanding",
        "intent",
        "thoughts",
        "confirmed",
        "pending",
        "spoken",
        "dropped",
        "heavy_runs",
        "proposals",
        "version",
    ):
        print("%-14s %s" % (key + ":", report[key]))
    if engine.state.spoken:
        print()
        print("--- spoken trace ---")
        for utterance in engine.state.spoken:
            print("[%s] %s" % (utterance.kind, utterance.text))
    if engine.state.dropped:
        print()
        print("--- dropped drafts ---")
        for utterance in engine.state.dropped:
            print("[%s] %s" % (utterance.note, utterance.text))


async def _demo(args) -> int:
    name = args.scenario or "add-info"
    if name not in SCENARIOS:
        print("unknown scenario %r; known: %s" % (name, ", ".join(sorted(SCENARIOS))), file=sys.stderr)
        return 2
    config = _config_from_args(args)
    engine = Engine(config)
    async with engine:
        await engine.run_script(load_script(name))
    print("# scenario: %s (backend: %s)" % (name, config.backend))
    print()
    print(engine.transcript.render())
    if not args.quiet:
        _print_report(engine)
    return 0


async def _chat(args) -> int:
    config = _config_from_args(args)
    engine = Engine(config)
    loop = asyncio.get_event_loop()
    print("Undertone (concept-stage prototype). Empty line quits.")
    async with engine:
        while True:
            sys.stdout.write("you> ")
            sys.stdout.flush()
            line = await loop.run_in_executor(None, sys.stdin.readline)
            text = line.strip()
            if not text:
                break
            half = max(1, len(text) // 2)
            await engine.user_typing(text[:half])
            await asyncio.sleep(0.4)
            await engine.user_typing(text)
            await asyncio.sleep(0.4)
            await engine.user_send(text)
            await asyncio.sleep(1.2)
        print()
        print(engine.transcript.render())
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="undertone",
        description="Parallel-thinking architecture for real-time text dialogue (concept-stage prototype).",
    )
    sub = parser.add_subparsers(dest="command")

    demo = sub.add_parser("demo", help="replay a scripted conversation")
    demo.add_argument("--scenario", default="add-info", help="scenario name (default: add-info)")
    demo.add_argument("--quiet", action="store_true", help="hide the state report")

    chat = sub.add_parser("chat", help="talk to it from the terminal")
    for command in (demo, chat):
        command.add_argument("--backend", default=None, help="mock (default) or openai")
        command.add_argument("--base-url", default=None, help="OpenAI-compatible base URL")
        command.add_argument("--light-model", default=None)
        command.add_argument("--heavy-model", default=None)
        command.add_argument("--api-key", default=None)

    sub.add_parser("scenarios", help="list bundled scenarios")
    return parser


def main(argv=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    command = args.command or "demo"
    if command == "scenarios":
        for name, steps in SCENARIOS.items():
            print("%-12s %d events" % (name, len(steps)))
        return 0
    if command == "chat":
        return asyncio.run(_chat(args))
    return asyncio.run(_demo(args))
