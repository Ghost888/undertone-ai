"""The on-demand heavy layer.

The light layer escalates when something is worth deeper thought (a finished
message, a hard question, an interruption that changes the picture). The heavy
layer produces the thought that guides the answer and is the only layer allowed
to confirm one.
"""

from __future__ import annotations

import asyncio

from ..llm import parse_json
from ..module import Module
from ..state import Confidence


class HeavyThinker(Module):
    name = "heavy"

    def __init__(self, state, backend, config) -> None:
        super().__init__(state, config)
        self.backend = backend
        self.idle_timeout = config.thinking_tick
        self._last_run = 0.0
        self.runs = 0

    async def step(self) -> None:
        if not self.state.needs_deep_thought:
            return
        now = self.state.now()
        if now - self._last_run < self.config.deep_thought_cooldown:
            return
        self._last_run = now
        self.state.needs_deep_thought = False  # consumed, no extra version needed

        payload = {
            "role": "heavy",
            "understanding": self.state.understanding,
            "intent": self.state.intent,
            "thoughts": [t.to_dict() for t in self.state.thoughts.values()],
            "last_user_text": (
                self.state.last_event().text if self.state.last_event() is not None else ""
            ),
        }
        raw = await asyncio.to_thread(self.backend.complete, "heavy", payload)
        delta = parse_json(raw) or {}
        text = str(delta.get("thought") or delta.get("text") or "").strip()
        if not text:
            return
        self.runs += 1
        self.state.upsert_thought("heavy:plan", text, Confidence.CONFIRMED, source="heavy")
