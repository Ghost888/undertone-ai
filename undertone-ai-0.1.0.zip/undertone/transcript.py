"""The visible dialogue plus a small audit trail."""

from __future__ import annotations

from typing import Dict, List


class Transcript:
    def __init__(self) -> None:
        self.lines: List[Dict[str, object]] = []

    def emit(self, speaker: str, text: str, kind: str = "reply", ts=None) -> None:
        self.lines.append({"speaker": speaker, "text": text, "kind": kind, "ts": ts})

    def assistant_lines(self) -> List[Dict[str, object]]:
        return [line for line in self.lines if line["speaker"] == "assistant"]

    def count(self, speaker: str = None, kind: str = None) -> int:
        total = 0
        for line in self.lines:
            if speaker is not None and line["speaker"] != speaker:
                continue
            if kind is not None and line["kind"] != kind:
                continue
            total += 1
        return total

    def render(self, tags: bool = True) -> str:
        rendered = []
        for line in self.lines:
            kind = str(line["kind"])
            tag = " [%s]" % kind if tags and kind not in ("send", "reply") else ""
            rendered.append("%s%s: %s" % (line["speaker"], tag, line["text"]))
        return "\n".join(rendered)

    def __len__(self) -> int:
        return len(self.lines)
