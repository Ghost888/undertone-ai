"""Runtime knobs for the prototype.

Every number here is a hypothesis, not a tuned constant: they are the first
things the experiments are supposed to move. See docs/design-notes.md.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Config:
    # --- perception ---------------------------------------------------
    pause_after: float = 0.9
    """Silence while typing (seconds) that counts as a "pause" event."""

    typing_timeout: float = 2.5
    """Silence after which the "user is typing" flag is cleared."""

    # --- thinking -----------------------------------------------------
    light_min_interval: float = 0.15
    """Minimum gap between two light-layer calls (rate limit / cost guard)."""

    deep_thought_cooldown: float = 0.5
    """Minimum gap between two heavy-layer escalations."""

    light_model: str = "light-model"
    heavy_model: str = "heavy-model"

    # --- expression / scheduler ---------------------------------------
    proposal_max_age: float = 6.0
    """A draft older than this is considered cold and dropped."""

    max_pending: int = 3
    """How many unspoken drafts may wait in the state at once."""

    backchannel_after: float = 1.4
    """Silence while typing before "mm..." is worth saying."""

    backchannel_min_gap: float = 3.5
    """Minimum gap between two backchannels."""

    # --- module loops --------------------------------------------------
    perception_tick: float = 0.1
    thinking_tick: float = 0.2
    scheduler_tick: float = 0.1

    # --- backends ------------------------------------------------------
    backend: str = "mock"
    """Either "mock" (no network, deterministic) or "openai" (OpenAI-compatible API)."""

    base_url: str = "http://localhost:11434/v1"
    api_key: str = ""
    request_timeout: float = 60.0

    mock_latency: float = 0.0
    """Seconds the mock backend sleeps, to make concurrency visible."""

    mock_heavy_latency: float = 0.0

    # --- scripts / demos -------------------------------------------------
    tail_delay: float = 1.5
    """How long a scripted run keeps the engine running after the last event."""
