import unittest

from undertone.events import EventKind, InputEvent
from undertone.state import Confidence, SharedState, Utterance


def make_state(now=100.0):
    return SharedState(clock=lambda: now)


class VersioningTests(unittest.TestCase):
    def test_writes_bump_the_version(self):
        state = make_state()
        start = state.version
        state.append_event(InputEvent(EventKind.SEND, "hi", ts=100.0))
        self.assertGreater(state.version, start)

        before = state.version
        state.set_understanding("the user said hi")
        self.assertGreater(state.version, before)

        before = state.version
        state.set_understanding("the user said hi")  # idempotent
        self.assertEqual(state.version, before)

    def test_unchanged_thought_does_not_move_its_version(self):
        state = make_state()
        first = state.upsert_thought("plan", "answer briefly", Confidence.CONFIRMED)
        second = state.upsert_thought("plan", "answer briefly", Confidence.CONFIRMED)
        self.assertEqual(first.version, second.version)

    def test_revised_thought_moves_its_version(self):
        state = make_state()
        first = state.upsert_thought("plan", "v1", Confidence.CONFIRMED)
        second = state.upsert_thought("plan", "v2", Confidence.CONFIRMED)
        self.assertGreater(second.version, first.version)


class StalenessTests(unittest.TestCase):
    def test_proposal_goes_stale_when_a_thought_is_revised(self):
        state = make_state()
        thought = state.upsert_thought("plan", "v1", Confidence.CONFIRMED)
        draft = Utterance(
            text="answer",
            thought_versions={thought.id: thought.version},
            ts=100.0,
        )
        self.assertFalse(state.is_stale(draft))
        state.upsert_thought("plan", "v2", Confidence.CONFIRMED)
        self.assertTrue(state.is_stale(draft))

    def test_proposal_with_unknown_thought_is_stale(self):
        state = make_state()
        draft = Utterance(text="answer", thought_versions={"ghost": 1}, ts=100.0)
        self.assertTrue(state.is_stale(draft))

    def test_take_pending_skips_stale_and_returns_newest(self):
        state = make_state()
        old = Utterance(text="old", ts=100.0)
        stale_thought = state.upsert_thought("plan", "v1", Confidence.CONFIRMED)
        stale = Utterance(text="stale", thought_versions={stale_thought.id: stale_thought.version}, ts=101.0)
        state.upsert_thought("plan", "v2", Confidence.CONFIRMED)
        state.propose(old)
        state.propose(stale)

        taken = state.take_pending(lambda u: u.kind == "reply")
        self.assertIsNotNone(taken)
        self.assertEqual(taken.text, "old")
        self.assertEqual(len(state.dropped), 1)
        self.assertEqual(state.dropped[0].text, "stale")


class SignalTests(unittest.TestCase):
    def test_confidence_normalization(self):
        state = make_state()
        thought = state.upsert_thought("x", "y", "CONFIRMED")
        self.assertEqual(thought.confidence, Confidence.CONFIRMED)
        thought = state.upsert_thought("z", "w", "noise")
        self.assertEqual(thought.confidence, Confidence.TENTATIVE)

    def test_silence_uses_last_input(self):
        state = SharedState(clock=lambda: 105.0)
        self.assertEqual(state.silence(), float("inf"))
        state.append_event(InputEvent(EventKind.TYPING, "hi", ts=102.0))
        self.assertAlmostEqual(state.silence(), 3.0)


if __name__ == "__main__":
    unittest.main()
