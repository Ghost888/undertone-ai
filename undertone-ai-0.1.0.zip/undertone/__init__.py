"""Undertone - think while you type.

A parallel-thinking architecture for real-time text dialogue, at concept stage.
The package is a runnable skeleton of the architecture described in the README:
a versioned shared state, perception, a light and a heavy thinking layer,
expression, and a rule-based scheduler that is the only module allowed to speak.
"""

from .config import Config
from .engine import Engine
from .events import EventKind, InputEvent
from .state import Confidence, SharedState, Thought, Utterance
from .transcript import Transcript

__version__ = "0.1.0"

__all__ = [
    "Config",
    "Engine",
    "Transcript",
    "EventKind",
    "InputEvent",
    "SharedState",
    "Thought",
    "Utterance",
    "Confidence",
    "__version__",
]
